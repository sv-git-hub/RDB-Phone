package com.mistywillow.researchdb;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class QuoteTermFragment extends Fragment {
    TextView quote;
    TextView term;
    String strQuote;
    String strTerm;

    public QuoteTermFragment(String quote, String term){
        this.strQuote = quote;
        this.strTerm = term;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.view_tab_quote_term, container, false);
        quote = view.findViewById(R.id.tab_View_Quote);
        term = view.findViewById(R.id.tab_View_Term);
        quote.setText(strQuote);
        term.setText(strTerm);

        //return super.onCreateView(inflater, container, savedInstanceState);
        return view;
    }
}
