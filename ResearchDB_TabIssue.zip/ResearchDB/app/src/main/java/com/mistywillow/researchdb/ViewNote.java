package com.mistywillow.researchdb;

import android.content.Intent;
import android.text.method.ScrollingMovementMethod;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.appcompat.widget.Toolbar;
import androidx.room.DatabaseConfiguration;
import androidx.room.InvalidationTracker;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteOpenHelper;
import androidx.viewpager.widget.ViewPager;
import com.google.android.material.tabs.TabItem;
import com.google.android.material.tabs.TabLayout;
import com.mistywillow.researchdb.database.*;
import com.mistywillow.researchdb.database.entities.Notes;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class ViewNote extends AppCompatActivity {
    ResearchDatabase researchDatabase;
    List<String> noteDetails = new ArrayList<>();

    TextView sourceType;
    TextView topic;
    TextView question;
    TextView source;
    TextView authors;
    TextView summary;
    TextView comment;
    TabLayout tabLayout;
    TabItem tabQuoteTerm;
    TabItem tabFiles;
    ViewPager mainViewPager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_note);
        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitleTextColor(getResources().getColor(R.color.colorWhite));
        setSupportActionBar(toolbar);


        sourceType = findViewById(R.id.viewSourceType);
        topic = findViewById(R.id.viewTopic);
        question = findViewById(R.id.viewQuestion);
        /*source = findViewById(R.id.viewSource);
        authors = findViewById(R.id.viewAuthors);*/
        summary = findViewById(R.id.viewSummary);
        comment = findViewById(R.id.viewComment);
        tabFiles = findViewById(R.id.tabFiles);
        tabQuoteTerm = findViewById(R.id.tabQuoteTerm);
        mainViewPager = findViewById(R.id.view_ViewPager);
        tabLayout = findViewById(R.id.view_Tab_Layout);

        // PREVENTS KEYBOARD POPPING UP ON ACTIVITY LOAD
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

        // RECEIVE INTENT FROM NOTE ADAPTER PASSING SELECTED NOTE ID
        Intent n = getIntent();
        int nNoteID = n.getIntExtra("ID", 0);
        String nType = n.getStringExtra("Type");
        String nSummary = n.getStringExtra("Summary");
        String nSource = n.getStringExtra("Source");
        String nAuthors = n.getStringExtra("Authors");

        researchDatabase = ResearchDatabase.getInstance(getApplicationContext(), "Apologetic.db");
        NoteDetails details = researchDatabase.getNotesDao().getNoteDetails(nNoteID);
        noteDetails.clear();
        noteDetails = loadAllNoteDetails(nType, nSummary, nSource, nAuthors, details);
        populateFields();

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        setupViewPager(mainViewPager);
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu); // MAIN MENU: Same Menu throughout the Application
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        finish();
        return super.onOptionsItemSelected(item);
    }

    public void closeApplication(){
        finish();
        moveTaskToBack(true);
    }

    private void setupViewPager(ViewPager viewPager){
        SectionsPageAdapter adapter = new SectionsPageAdapter(getSupportFragmentManager());
        adapter.addFragment(new SourceFragment(noteDetails.get(2), noteDetails.get(3)), "Source");
        adapter.addFragment(new QuoteTermFragment(noteDetails.get(5), noteDetails.get(6)), "Quote and Term");
        adapter.addFragment(new FilesFragment(), "File");
        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);
    }

    private void populateFields() {
        sourceType.setText(noteDetails.get(0));
        topic.setText(noteDetails.get(17));
        question.setText(noteDetails.get(4));
        /*source.setText(noteDetails.get(2));
        authors.setText(noteDetails.get(3));*/
        summary.setText(noteDetails.get(1));
        comment.setText(noteDetails.get(14));

    }

    private List<String> loadAllNoteDetails(String type, String summary, String source, String authors, NoteDetails noteDetails){
        List<String> nDetails = new ArrayList<>();
        nDetails.add(type);                         // 0: Type
        nDetails.add(summary);                      // 1: Summary
        nDetails.add(source);                       // 2: Source
        nDetails.add(authors);                      // 3: Author(s)

        nDetails.add(noteDetails.getQuestion());    // 4: Question
        nDetails.add(noteDetails.getQuote());       // 5: Quote
        nDetails.add(noteDetails.getTerm());        // 6: Term
        nDetails.add(noteDetails.getYear());        // 7: Year
        nDetails.add(noteDetails.getMonth());       // 8: Month
        nDetails.add(noteDetails.getDay());         // 9: Day
        nDetails.add(noteDetails.getVolume());      // 10: Volume
        nDetails.add(noteDetails.getEdition());     // 11: Edition
        nDetails.add(noteDetails.getIssue());       // 12: Issue
        nDetails.add(noteDetails.getHyperlink());   // 13: Hyperlink
        nDetails.add(noteDetails.getComment());     // 14: Comment
        nDetails.add(noteDetails.getPage());        // 15: Page
        nDetails.add(noteDetails.getTimeStamp());   // 16: TimeStamp
        nDetails.add(noteDetails.getTopic());       // 17: Topic
        return nDetails;
    }

    @Override
    public void onBackPressed() {
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
        //super.onBackPressed();
    }
}
