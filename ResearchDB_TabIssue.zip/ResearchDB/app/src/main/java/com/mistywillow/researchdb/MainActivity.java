package com.mistywillow.researchdb;

import android.content.res.Resources;
import android.util.Log;
import android.view.*;
import android.view.inputmethod.EditorInfo;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;
import androidx.sqlite.db.SimpleSQLiteQuery;
import androidx.viewpager.widget.ViewPager;
import com.mistywillow.researchdb.database.ResearchDatabase;
import com.mistywillow.researchdb.database.entities.*;


import javax.security.auth.Destroyable;
import java.util.*;

public class MainActivity extends AppCompatActivity {
    private Toolbar toolbar;
    private Spinner topic;
    private Spinner question;
    private RecyclerView rListNotes;
    private EditText customSearch;
    private ResearchDatabase researchDatabase;

    private List<SourcesTable> sourcesTableList;
    private RecyclerView.Adapter adapter;
    private NoteAdapter noteAdapter;
    private List<Integer> noteIDsFromCustomSearch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d("onCreate", "Starting");

        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitleTextColor(getResources().getColor(R.color.colorWhite));
        setSupportActionBar(toolbar);

        topic = findViewById(R.id.listTopic);
        question = findViewById(R.id.listQuestion);
        customSearch = findViewById(R.id.txtCustom);
        rListNotes = findViewById(R.id.listNotes);



        // PREVENTS KEYBOARD POPPING UP ON ACTIVITY LOAD
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

            // APP CREATED DATABASE
            /*researchDatabase = Room.databaseBuilder(getApplicationContext(), ResearchDatabase.class, "Apologetic.db").allowMainThreadQueries().build();
            researchDatabase.getOpenHelper().getWritableDatabase();*/

            // MY DATABASE:
            researchDatabase = ResearchDatabase.getInstance(this, "Apologetic.db");/**/
            /*researchDatabase = Room.databaseBuilder(this, ResearchDatabase.class, "Apologetic.db")
                    .createFromAsset("databases/Android.db")
                    .allowMainThreadQueries().fallbackToDestructiveMigration().build();*/

            // TOPIC LIST
            List<Topics> arrTopics = researchDatabase.getTopicsDao().getTopics();
            final List<String> nTopics = new ArrayList<>();
            nTopics.add("");
            for (Topics t: arrTopics) {
                nTopics.add(t.getTopic());
            }
            ArrayAdapter<String> topicAdapter = new ArrayAdapter<>(this, R.layout.custom_topic_spinner, nTopics);
            topic.setAdapter(topicAdapter);
            topic.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    if(!topic.getSelectedItem().toString().equals("")) {
                        question.setSelection(0);
                        rListNotes.setAdapter(null);
                        customSearch.setText(null);
                        loadNotes(captureNotes(researchDatabase.getNotesDao().getNotesOnTopic(parent.getItemAtPosition(position).toString())));
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });

            // QUESTION LIST
            List<Questions> arrQuestions = researchDatabase.getQuestionsDao().getQuestions();
            List<String> nQuestions = new ArrayList<>();
            nQuestions.add("");
            for (Questions q: arrQuestions) {
                nQuestions.add(q.getQuestion());
            }
            final ArrayAdapter<String> questionAdapter = new ArrayAdapter<>(this, R.layout.custom_question_spinner, nQuestions);
            question.setAdapter(questionAdapter);
            question.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    if(!question.getSelectedItem().toString().equals("")) {
                        topic.setSelection(0);
                        rListNotes.setAdapter(null);
                        customSearch.setText(null);
                        loadNotes(captureNotes(researchDatabase.getNotesDao().getNotesOnQuestion(parent.getItemAtPosition(position).toString())));
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });

            // CUSTOM SEARCH
            customSearch.setOnEditorActionListener(new TextView.OnEditorActionListener() {
                @Override
                public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {

                    if(actionId == EditorInfo.IME_ACTION_DONE)
                        if(!customSearch.getText().toString().trim().equals("")){
                            noteIDsFromCustomSearch = new ArrayList<>();
                            rListNotes.setAdapter(null);
                            completeSearch(false, customSearch.getText().toString());
                            loadNotes(captureNotes(researchDatabase.getNotesDao().getAllNotesOnNoteIDs(noteIDsFromCustomSearch)));

                            Toast.makeText(getApplicationContext(), String.valueOf(noteIDsFromCustomSearch.size()), Toast.LENGTH_SHORT).show();
                        }

                    return false;
                }
            });
            customSearch.setOnKeyListener(new View.OnKeyListener() {
                @Override
                public boolean onKey(View v, int keyCode, KeyEvent event) {
                    topic.setSelection(0);
                    question.setSelection(0);
                    rListNotes.setAdapter(null);
                    return false;
                }
            });
    }

    // MENU METHODS
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //return super.onCreateOptionsMenu(menu);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        //AppManager.manageMenuClicks(this, item);

        if(item.getItemId() == R.id.clear) {
            clearFields();
            Toast.makeText(this, "Clear Fields clicked!", Toast.LENGTH_SHORT).show();
        }else if(item.getItemId() == R.id.add_note) {
            Toast.makeText(this, "Add Note clicked!", Toast.LENGTH_SHORT).show();
        }else if(item.getItemId() == R.id.mark_for_delete) {
            Toast.makeText(this, "Mark Note for Delete clicked!", Toast.LENGTH_SHORT).show();
        }else if(item.getItemId() == R.id.unMark_for_delete) {
            Toast.makeText(this, "Unmark Note for Delete clicked!", Toast.LENGTH_SHORT).show();
        }else if(item.getItemId() == R.id.review_for_delete) {
            Toast.makeText(this, "Review Notes for Delete clicked!", Toast.LENGTH_SHORT).show();
        }else if(item.getItemId() == R.id.permanently_delete) {
            Toast.makeText(this, "Permanently Delete Note clicked!", Toast.LENGTH_SHORT).show();
        }else if(item.getItemId() == R.id.delete_database) {
            Toast.makeText(this, "Delete Database clicked!", Toast.LENGTH_SHORT).show();
        }else if(item.getItemId() == R.id.main_close) {
            closeApplication();
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    // CUSTOM METHODS
    public void clearFields(){
        topic.setSelection(0);
        question.setSelection(0);
        customSearch.setText(null);
        rListNotes.setAdapter(null);
    }

    public void closeApplication(){
        finish();
        moveTaskToBack(true);
    }

    private List<SourcesTable> captureNotes(List<SourcesTable> list){
        sourcesTableList = list;
        return sourcesTableList;
    }

    private void loadNotes(List<SourcesTable> sourcesTable){
        rListNotes.setLayoutManager(new LinearLayoutManager(MainActivity.this));
        noteAdapter = new NoteAdapter(MainActivity.this, researchDatabase, sourcesTable);
        adapter = noteAdapter;
        rListNotes.setAdapter(noteAdapter);
    }

    private void completeSearch(Boolean all, String criteria){
        captureCustomSearchNoteIDs("Sources", "SourceID", researchDatabase.getSourcesDao().customSearchSourcesTable(searchTable(all, criteria, "Sources", "SourceID", Collections.singletonList("Title"))));
        captureCustomSearchNoteIDs("Comments", "CommentID", researchDatabase.getCommentsDao().customSearchCommentsTable(searchTable(all, criteria,"Comments", "CommentID", Arrays.asList("Summary", "Comment", "Page", "TimeStamp","Hyperlink"))));
        captureCustomSearchNoteIDs("Questions", "QuestionID", researchDatabase.getQuestionsDao().customSearchQuestionsTable(searchTable(all, criteria, "Questions", "QuestionID", Collections.singletonList("Question"))));
        captureCustomSearchNoteIDs("Quotes", "QuoteID", researchDatabase.getQuotesDao().customSearchQuotesTable(searchTable(all, criteria, "Quotes", "QuoteID", Collections.singletonList("Quote"))));
        captureCustomSearchNoteIDs("Terms", "TermID", researchDatabase.getTermsDao().customSearchTermsTable(searchTable(all, criteria, "Terms", "TermID", Collections.singletonList("Term"))));
        captureCustomSearchNoteIDs("Topics", "TopicID", researchDatabase.getTopicsDao().customSearchTopicsTable(searchTable(all, criteria, "Topics", "TopicID", Collections.singletonList("Topic"))));
        captureCustomSearchNoteIDs("Files", "FileID", researchDatabase.getFilesDao().customSearchFilesTable(searchTable(all, criteria, "Files", "FileID", Collections.singletonList("FileName"))));
        captureCustomSearchNoteIDs("Authors", "AuthorID", researchDatabase.getTopicsDao().customSearchTopicsTable(searchTable(all, criteria, "Authors", "AuthorID", Arrays.asList("FirstName", "MiddleName", "LastName", "Suffix"))));
    }

    private SimpleSQLiteQuery searchTable(boolean all, String criteria, String table, String tableID, List<String> columnNames){
        String statement = "SELECT " + tableID + " FROM " + table + " WHERE" + searchColumns(all, criteria, columnNames);
        return new SimpleSQLiteQuery(statement);

    }

    private void captureCustomSearchNoteIDs(String table, String tableID, List<Integer> tableList){
        List<Integer> temp = new ArrayList<>();
        String query = "";
        for(Integer id : tableList) {
            if (table.equals("Files"))
                query = "SELECT NoteID FROM " + table + "_By_Note WHERE " + tableID + " = " + id;
            else if (table.equals("Authors"))
                query = "SELECT NoteID FROM Notes AS n " +
                        "LEFT JOIN Author_By_Source AS s " +
                        "WHERE " + id + " = s.AuthorID AND s.SourceID = n.SourceID";
            else
                query = "SELECT NoteID FROM Notes WHERE " + tableID + " = " + id;
            temp.addAll(researchDatabase.getNotesDao().getNotesOnCustomSearch(new SimpleSQLiteQuery(query)));
        }
        for (Integer i : temp) {
            if(!noteIDsFromCustomSearch.contains(i))
                noteIDsFromCustomSearch.add(i);
        }
    }

    // CONCATENATION METHODS
    private String searchColumns(boolean containsAll, String criteria, List<String> columns){

        StringBuilder sb = new StringBuilder();

        for(String str : columns){
            if(columns.indexOf(str) == 0)
                sb.append(searchWords(containsAll, str, criteria));
            else
                sb.append(" OR ").append(searchWords(containsAll, str, criteria));
        }
        return sb.toString();
    }

    private String searchWords(boolean containsAll, String column, String words){
        StringBuilder sb = new StringBuilder();
        List<String> word = Arrays.asList(words.split(" "));
        String operator = " OR ";
        if(containsAll)
            operator = " AND ";

        for(String str : word){
            if(word.indexOf(str) == 0)
                sb.append(" ").append(column).append(" LIKE '%").append(str.replace("'", "''")).append("%'");
            else
                sb.append(operator).append(column).append(" LIKE '%").append(str.replace("'", "''")).append("%'");
        }
        return sb.toString();
    }


}

/*    Spinner spinner = (Spinner)findViewById(R.id.spinner);
    String text = spinner.getSelectedItem().toString();*/
