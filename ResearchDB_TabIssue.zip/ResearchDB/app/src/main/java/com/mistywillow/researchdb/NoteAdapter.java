package com.mistywillow.researchdb;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.mistywillow.researchdb.database.*;
import com.mistywillow.researchdb.database.entities.Authors;


import java.util.List;

public class NoteAdapter extends RecyclerView.Adapter<NoteAdapter.ViewHolder> {

    private LayoutInflater inflater;
    private List<SourcesTable> notes;
    private ResearchDatabase db;

    public NoteAdapter(Context context, ResearchDatabase db, List<SourcesTable> notes){
        this.inflater = LayoutInflater.from(context);
        this.notes = notes;
        this.db = db;
    }

    @NonNull
    @Override
    public NoteAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view = inflater.inflate(R.layout.custom_notes_list, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NoteAdapter.ViewHolder viewHolder, int i) {

        int noteID = notes.get(i).getNoteID();
        String noteType = notes.get(i).getSourceType();
        String noteSummary = notes.get(i).getSummary();
        String noteSource = notes.get(i).getTitle();
        String noteAuthors = getAllAuthors(notes.get(i).getSourceID());
        viewHolder.nNoteID.setText(String.valueOf(noteID));
        viewHolder.nNoteType.setText(noteType);
        viewHolder.nSummary.setText(noteSummary);
        viewHolder.nSource.setText(noteSource);
        viewHolder.nAuthors.setText(noteAuthors);

    }

    @Override
    public int getItemCount() {
        return notes.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView nNoteID;
        TextView nNoteType;
        TextView nSummary;
        TextView nSource;
        TextView nAuthors;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            nNoteID = itemView.findViewById(R.id.nNoteID);
            nNoteType = itemView.findViewById(R.id.nNoteSourceType);
            nSummary = itemView.findViewById(R.id.nNoteSummary);
            nSource = itemView.findViewById(R.id.nNoteSource);
            nAuthors = itemView.findViewById(R.id.nNoteAuthors);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(v.getContext(), ViewNote.class);
                    i.putExtra("ID", notes.get(getAdapterPosition()).getNoteID());
                    i.putExtra("Type", notes.get(getAdapterPosition()).getSourceType());
                    i.putExtra("Summary", notes.get(getAdapterPosition()).getSummary());
                    i.putExtra("Source", notes.get(getAdapterPosition()).getTitle());
                    i.putExtra("Authors", getAllAuthors(notes.get(getAdapterPosition()).getSourceID()));
                    v.getContext().startActivity(i);
                }
            });

        }
    }

    private String getAllAuthors(int sourceID){
        List<Authors> authors = db.getAuthorsDao().getSourceAuthors(sourceID);
        return concatenateAuthors(authors);
    }

    private String concatenateAuthors(List<Authors> authors){
        StringBuilder str = new StringBuilder();
        for(int i = 0 ; i < authors.size(); i++){
            str.append(authors.get(i).getFirstName().trim());
            if(!authors.get(i).getMiddleName().isEmpty())
                str.append(" ").append(authors.get(i).getMiddleName().trim());
            if(!authors.get(i).getLastName().isEmpty())
                str.append(" ").append(authors.get(i).getLastName().trim());
            if(!authors.get(i).getSuffix().isEmpty())
                str.append(" ").append(authors.get(i).getSuffix().trim());
            if(authors.size()> 1 && (i+1) < authors.size())
                str.append("; ");
        }
        return str.toString().trim();
    }

}
