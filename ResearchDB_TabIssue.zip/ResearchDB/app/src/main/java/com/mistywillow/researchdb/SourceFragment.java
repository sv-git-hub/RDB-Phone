package com.mistywillow.researchdb;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class SourceFragment extends Fragment {
    TextView source;
    TextView author;
    String strSource;
    String strAuthors;

    public SourceFragment(String source, String author){
        this.strSource = source;
        this.strAuthors = author;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.view_tab_source, container, false);
        source = view.findViewById(R.id.tab_View_Source);
        author = view.findViewById(R.id.tab_View_Authors);
        source.setText(strSource);
        author.setText(strAuthors);

        //return super.onCreateView(inflater, container, savedInstanceState);
        return view;
    }
}
