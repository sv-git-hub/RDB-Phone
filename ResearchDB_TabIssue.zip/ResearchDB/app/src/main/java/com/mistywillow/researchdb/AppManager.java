package com.mistywillow.researchdb;

import android.content.Context;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

public class AppManager {

    public static void manageMenuClicks(Context context, MenuItem item) {

        if (item.getItemId() == R.id.clear) {
            Toast.makeText(context, "Clear Fields clicked!", Toast.LENGTH_SHORT).show();
        } else if (item.getItemId() == R.id.add_note) {
            Toast.makeText(context, "Add Note clicked!", Toast.LENGTH_SHORT).show();
        } else if (item.getItemId() == R.id.mark_for_delete) {
            Toast.makeText(context, "Mark Note for Delete clicked!", Toast.LENGTH_SHORT).show();
        } else if (item.getItemId() == R.id.unMark_for_delete) {
            Toast.makeText(context, "Unmark Note for Delete clicked!", Toast.LENGTH_SHORT).show();
        } else if (item.getItemId() == R.id.review_for_delete) {
            Toast.makeText(context, "Review Notes for Delete clicked!", Toast.LENGTH_SHORT).show();
        } else if (item.getItemId() == R.id.permanently_delete) {
            Toast.makeText(context, "Permanently Delete Note clicked!", Toast.LENGTH_SHORT).show();
        } else if (item.getItemId() == R.id.delete_database) {
            Toast.makeText(context, "Delete Database clicked!", Toast.LENGTH_SHORT).show();
        } else if (item.getItemId() == R.id.main_close) {
            //closeApplication();
        }
    }

}
