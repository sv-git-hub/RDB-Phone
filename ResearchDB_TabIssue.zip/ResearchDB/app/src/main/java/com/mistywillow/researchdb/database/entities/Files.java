package com.mistywillow.researchdb.database.entities;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "Files")
public class Files {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "FileID")
    private int fileID;
    @ColumnInfo(name = "FileName")
    private String fileName;
    @ColumnInfo(name = "FileData")
    private String fileData;

    public Files(String fileName, String fileData){
        this.fileName = fileName;
        this.fileData = fileData;
    }

    public int getFileID() {
        return fileID;
    }

    public void setFileID(int fileID){ this.fileID = fileID; }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFileData() {
        return fileData;
    }

    public void setFileData(String fileData) {
        this.fileData = fileData;
    }
}
