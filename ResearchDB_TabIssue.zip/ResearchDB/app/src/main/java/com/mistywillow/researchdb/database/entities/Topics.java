package com.mistywillow.researchdb.database.entities;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "Topics")
public class Topics {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "TopicID")
    private int topicID;
    @ColumnInfo(name = "Topic")
    private String topic;

    public Topics(String topic){
        this.topic = topic;
    }

    public int getTopicID() {
        return topicID;
    }

    public void setTopicID(int topicID) {
        this.topicID = topicID;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }
}
