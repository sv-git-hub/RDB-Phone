package com.mistywillow.researchdb.database;

import androidx.room.*;
import androidx.sqlite.db.SupportSQLiteQuery;
import com.mistywillow.researchdb.database.entities.Comments;

import java.util.List;

@Dao
public interface CommentsDao {
    @Insert
    void addComment(Comments comment);
    @Update
    void updateComment(Comments comment);
    @Delete
    void deleteComment(Comments comment);

    @Query("SELECT * FROM Comments")
    List<Comments> getComments();

    @Query("SELECT * FROM Comments WHERE CommentID = :commentID")
    Comments getComment(int commentID);

    /*@Query("SELECT CommentID FROM Comments WHERE Comment LIKE :value")
    List<Integer> customSearchCommentsTable(String value);*/

    @RawQuery
    List<Integer> customSearchCommentsTable(SupportSQLiteQuery query);
}
