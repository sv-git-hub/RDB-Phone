package com.mistywillow.researchdb;

import java.util.List;

public class BuildSpinner {

    public static List<String> TypeSpinner(){
        //ResearchDatabase rdb = ResearchDatabase.getInstance(getApplicationContext(),"Apologetic.db");


        return null;
    }


}
